/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio;

/**
 *
 * @author tahay
 */
public class Producto {
    private String Nombre, Perecedero, Fecha;
    private int Stock, StockMin, id;
    private double Compra, Venta;
    private static int NoProducto = 0;

    public Producto(String Nombre, String Perecedero, String Fecha, int Stock, int StockMin, double Compra, double Venta) {
        this.Nombre = Nombre;
        this.Perecedero = Perecedero;
        this.Fecha = Fecha;
        this.Stock = Stock;
        this.StockMin = StockMin;
        this.Compra = Compra;
        this.Venta = Venta;
        NoProducto++;
        this.id = NoProducto;
    }

    public Producto(String Nombre, String Perecedero, String Fecha, int Stock, int StockMin, int id, double Compra, double Venta) {
        this.Nombre = Nombre;
        this.Perecedero = Perecedero;
        this.Fecha = Fecha;
        this.Stock = Stock;
        this.StockMin = StockMin;
        this.id = id;
        this.Compra = Compra;
        this.Venta = Venta;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getPerecedero() {
        return Perecedero;
    }

    public String getFecha() {
        return Fecha;
    }

    public int getStock() {
        return Stock;
    }

    public int getStockMin() {
        return StockMin;
    }

    public int getId() {
        return id;
    }

    public double getCompra() {
        return Compra;
    }

    public double getVenta() {
        return Venta;
    }

    public static int getNoProducto() {
        return NoProducto;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setPerecedero(String Perecedero) {
        this.Perecedero = Perecedero;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }

    public void setStockMin(int StockMin) {
        this.StockMin = StockMin;
    }

    public void setCompra(double Compra) {
        this.Compra = Compra;
    }

    public void setVenta(double Venta) {
        this.Venta = Venta;
    }
    
    
    
    
    
    
}
