/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio;

/**
 *
 * @author tahay
 */
public class Ejercicio {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Inter in = new Inter();
        in.setVisible(true);
    }
}
