/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio;

import java.util.ArrayList;

/**
 *
 * @author tahay
 */
public class Transferencia {
    private static Producto producto;
    private static ArrayList<Producto> prds = new ArrayList();

    public static Producto getProducto() {
        return producto;
    }

    public static ArrayList<Producto> getPrds() {
        return prds;
    }

    public static void setProducto(Producto producto) {
        Transferencia.producto = producto;
    }

    public static void setPrds(Producto producto) {
        Transferencia.prds.add(producto);
    }

    
}
